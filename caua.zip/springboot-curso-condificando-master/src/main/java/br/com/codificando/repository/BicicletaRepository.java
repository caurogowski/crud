package br.com.codificando.repository;

import .java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BicicletaRepository extends JpaRepository<BicicletaRepository, Long>{
	
	public List<Bicicleta> findAllByCargo(String cargo);
	public List<Bicicleta> findByCargoNot(String cargo);

}
