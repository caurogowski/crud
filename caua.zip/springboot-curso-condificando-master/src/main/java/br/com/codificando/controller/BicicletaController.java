package br.com.codificando.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import br.com.codificando.model.Bicicleta;
import br.com.codificando.repository.BicicletaRepository;

@Controller

public class BicicletaController {
	
	@Autowired

	private BiciletaRepository BicicletaRespository;
	
	@GetMapping
			("/bicicleta/list")
	public String
	listBicicleta
			(Model model) {
		
		model.addAttribute("bicicleta", BicicletaRespository.findAll(Sort.by("cargo")));
		
		//String login = SecurityContextHolder.getContext().getAuthentication().getName();
		//System.out.println("Usuário logado: " + login);
		
		return "bicicleta/list";
	}
	
	@GetMapping("/bicicleta/add")
	public String addBicicleta(Model model) {
		
		model.addAttribute("bicicleta", new BicicletaController();
		return "bicicleta/add";
		
	}
	
	@PostMapping("/bicicleta/save")
	public String saveBicicleta(Bicicleta Bicicleta) {
		try {
			if (bicicleta != null) {
				BicicletaRespository.save( );
			}	
		} catch (Exception e) {
			System.out.println("Erro ao salvar: " + e.getMessage());
		}
		
		return "redirect:/bicicleta/view/" + bicicleta.getId() + "/" + true;
		
	}
	
	@GetMapping("/bicicleta/view/{id}/{salvo}")
	public String viewBicicleta(@PathVariable long id, @PathVariable boolean salvo, Model model) {
		model.addAttribute("bicicleta", BicicletaRespository.findById(id));
		model.addAttribute("salvo", salvo);
		return "bicicleta/view";
	}
	
	@GetMapping("/bicicleta/edit/{id}")
	public String editBicicleta(@PathVariable long id, Model model) {
		
		model.addAttribute("bicicleta", BicicletaRespository.findById(id));
		return "bicicleta/edit";
		
	}
	
	@GetMapping("/bicicleta/delete/{id}")
	public String deletebicicleta(@PathVariable long id) {
		try {
			BicicletaRespository.deleteById(id);
		} catch (Exception e) {
			System.out.println("Erro: " + e.getMessage());
		}
		return "redirect:/bicicleta/list";
	}
	

}
